import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";


const ServerHandler = function (req, res) {
  const url = req.url;
  const method = req.method;
  const __filename = fileURLToPath(import.meta.url);
  const __dirname = path.dirname(__filename);

  if (url.startsWith("/recursos/")) {
  const filePath = path.join(__dirname, "..", url);
  const ext = path.extname(filePath);

  const contentTypeMap = {
    ".jpg": "image/jpeg",
    ".jpeg": "image/jpeg",
    ".png": "image/png",
    ".gif": "image/gif",
    ".svg": "image/svg+xml"
  };

  fs.readFile(filePath, (err, data) => {
    if (err) {
      res.statusCode = 404;
      res.end("Archivo no encontrado");
    } else {
      res.setHeader("Content-Type", contentTypeMap[ext] || "application/octet-stream");
      res.end(data);
    }
  });
  return;
}

  if (url === "/") {
    fs.readFile("index.html", "utf-8", (err, data) => {
  if (err) throw err;
  res.setHeader("Content-Type", "text/html");
  res.end(data);
});

     } else if (url === "/contacto.html") {
    fs.readFile("contacto.html", "utf-8", (err, data) => {
  if (err) throw err;
  res.setHeader("Content-Type", "text/html");
  res.end(data);
  })

  } else if (url === "/message" && method === "POST") {
    const body = [];

    req.on("data", function (dataChunk) {
      body.push(dataChunk);
    });

   req.on("end", () => {
  const parsedBody = Buffer.concat(body).toString();

  const params = new URLSearchParams(parsedBody);
  const nombre = params.get("nombre")?.replaceAll("+", " ") || "";
  const apellido = params.get("apellido")?.replaceAll("+", " ") || "";
  const correo = params.get("correo")?.replaceAll("+", " ") || "";
  const descripcion = params.get("descripcion")?.replaceAll("+", " ") || "";

  const mensaje = `Nombre: ${nombre}\nApellido: ${apellido}\nCorreo: ${correo}\nDescripción: ${descripcion}\n`;

  fs.writeFile("datos.txt", mensaje, (err) => {
    res.statusCode = 302;
    res.setHeader("Location", "/contacto.html");
    res.end();
    console.log("datos guardado");
  });
});

    
  } else if (url === "/skill.html") {
    fs.readFile("skill.html", "utf-8", (err, data) => {
  if (err) throw err;
  res.setHeader("Content-Type", "text/html");
  res.end(data);
});
 
  
  } else if (url === "/proyectos.html") {
    fs.readFile("proyectos.html", "utf-8", (err, data) => {
  if (err) throw err;
  res.setHeader("Content-Type", "text/html");
  res.end(data);
});

  
  } else if (url === "/valores.html") {
    fs.readFile("valores.html", "utf-8", (err, data) => {
  if (err) throw err;
  res.setHeader("Content-Type", "text/html");
  res.end(data);
});

  }else {
    res.setHeader("Content-Type", "text/html");
    res.write(`
    
        <html>
        
            <head> <title> Not found </title> </head>
            <body>

            <h1> 404 page not found </h1>
            <ul>
                <li>
                    <a href="/"> Home </a>
                </li>
            </ul>
            </body>

        </html>
    `);

    res.end();
  }
}

export default ServerHandler;
